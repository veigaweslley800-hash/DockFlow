﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TESTECOMDADOS
{
    public partial class MenuRestrito : Form
    {
        public MenuRestrito()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Message box exibe a pergunta, dialog retorna a quest Yes or NO.
            DialogResult resposta = MessageBox.Show(
                "Deseja reamente voltar?",
                "Voltar",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
                );

            // Se a resposta for sim, ele fecha.
            if (resposta == DialogResult.Yes)
            {
                //Ir para área restrita
                var menu = new Form1();
                menu.Show();

                //Esconde a janela de formulário.
                this.Visible = false;
            }
        }
    }
}
