﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace TESTECOMDADOS
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnEntrar_Click(object sender, EventArgs e)
        {
            try
            {
                //Verifica se o que foi difitado é igual ao valor estabelecido
                if (txtUsuario.Text.Equals("admin") && txtSenha.Text.Equals("123456"))
                {
                    //Ir para área restrita
                    var menu = new MenuRestrito();
                    menu.Show();

                    //Esconde a janela de formulário.
                    this.Visible = false;
                }
                else
                {
                    MessageBox.Show("Usuário ou senha Incorretos. Tenta Novamente!",
                                    "Desculpe!",
                                    MessageBoxButtons.OK, 
                                    MessageBoxIcon.Error);

                    txtUsuario.Focus();
                    txtSenha.Text = "";
                }


            }catch (Exception ex)
            {
                MessageBox.Show("Desculpe",
                                ex.Message,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
                    
            }
                    
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        { 

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (!checkBox1.Checked)
            {
                txtSenha.PasswordChar = '*'; //Esconde a senha
            }
            else
            {
                txtSenha.PasswordChar = '\0'; //Mostra a senha
            }

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            //Message box exibe a pergunta, dialog retorna a quest Yes or NO.
            DialogResult resposta = MessageBox.Show(
                "Deseja reamente sair?",
                "Sair",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
                );

            // Se a resposta for sim, ele fecha.
            if ( resposta == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void txtSenha_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
